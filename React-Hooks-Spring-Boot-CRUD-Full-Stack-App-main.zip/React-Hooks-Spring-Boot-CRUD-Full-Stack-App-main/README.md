# React-Hooks-Spring-Boot-CRUD-Full-Stack-App
In this course, we will learn how to build a complete full-stack web application using Spring boot as backend and React (React Hooks) as frontend. We will use MySQL database to store and retrieve the data.

## React Hooks + Spring Boot CRUD Full Stack Application Course on YouTube
https://youtube.com/playlist?list=PLGRDMO4rOGcNsCZuMB8ydjDNNWLY69Rpu
